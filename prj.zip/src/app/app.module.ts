import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ContactComponent } from './contact/contact.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './core/components/header/header.component';
import { FooterComponent } from './core/components/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { AddmovieComponent } from './admin/addmovie/addmovie.component';
import { UpdatemovieComponent } from './admin/updatemovie/updatemovie.component';
import { AddumovieComponent } from './admin/addumovie/addumovie.component';
import { UpdateumovieComponent } from './admin/updateumovie/updateumovie.component';
import { FilterPipe } from './filter.pipe';
import{BsDatepickerModule} from 'ngx-bootstrap/datepicker';
import { SeatchartComponent } from './user/seatchart/seatchart.component';
import { UserdetailsComponent } from './user/userdetails/userdetails.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ContactComponent,
    AdminComponent,
    UserComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    AddmovieComponent,
    UpdatemovieComponent,
    AddumovieComponent,
    UpdateumovieComponent,
    FilterPipe,
    SeatchartComponent,
    UserdetailsComponent,
    ResetPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,HttpModule,
    NgbModule,
    TooltipModule.forRoot()
 
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
