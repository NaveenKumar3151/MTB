import { Component, OnInit, ViewChild } from '@angular/core';
import{NgForm} from '@angular/forms'


@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  @ViewChild('f') public resetPasswordForm :NgForm;


  constructor() { }

  ngOnInit(): void {
  }
  submitted=false;

  onSubmit(f:NgForm){
    this.submitted=true;
    
    console.log(f.value);
    console.log(f.valid);
  }

}
