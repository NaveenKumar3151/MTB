import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddumovieComponent } from './addumovie.component';

describe('AddumovieComponent', () => {
  let component: AddumovieComponent;
  let fixture: ComponentFixture<AddumovieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddumovieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddumovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
