import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';

@Component({
  selector: 'app-addumovie',
  templateUrl: './addumovie.component.html',
  styleUrls: ['./addumovie.component.scss']
})
export class AddumovieComponent implements OnInit {

  constructor(private http: Http) { }
  confirmationString:string = "New item has been added";
  isAdded: boolean = false;
  productObj:object = {};
  

  addNewProduct = function(student2) {
    this.productObj = {
      "id":student2.id,
      "image":student2.image.replace("C:\\fakepath\\","/assets/images/"),
      "name": student2.name,
      "language": student2.language,
      "type": student2.type,
      "date": student2.date
    }
    this.http.post("http://localhost:5200/students2/", this.productObj).subscribe((res:Response) => {
      this.isAdded = true;
    })
  }

  ngOnInit() {
  }

}
