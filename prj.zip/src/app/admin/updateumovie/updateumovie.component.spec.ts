import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateumovieComponent } from './updateumovie.component';

describe('UpdateumovieComponent', () => {
  let component: UpdateumovieComponent;
  let fixture: ComponentFixture<UpdateumovieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateumovieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateumovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
