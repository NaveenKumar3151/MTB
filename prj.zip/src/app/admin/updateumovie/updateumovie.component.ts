import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import {ActivatedRoute } from '@angular/router';
import {Router} from '@angular/router';

@Component({
  selector: 'app-updateumovie',
  templateUrl: './updateumovie.component.html',
  styleUrls: ['./updateumovie.component.scss']
})
export class UpdateumovieComponent implements OnInit {


  id:number;
  data:any = {};
  students2 = [];
  exist = false;
  productObj:object = {};
  
  private headers = new Headers({ 'Content-Type': 'application/json'});

  constructor(private router: Router, private route: ActivatedRoute, private http: Http) { }

  updateProduct(student2) {
    this.productObj = {
      "id":student2.id,
      "image":student2.image.replace("C:\\fakepath\\","/assets/images/"),
      "name": student2.name,
      "language": student2.language,
      "type": student2.type,
      "date": student2.date
    };
    const url = `${"http://localhost:5200/students2"}/${this.id}`;
    this.http.put(url, JSON.stringify(this.productObj),{headers: this.headers})
      .toPromise()
      .then(() => {
        this.router.navigate(['/admin']);
      })
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = +params['id'];
    });
    this.http.get("http://localhost:5200/students2").subscribe(
      (res: Response) => {
        this.students2 = res.json();
        for(var i = 0; i < this.students2.length ; i++) {
          if(parseInt(this.students2[i].id) === this.id) {
            this.exist = true;
            this.data = this.students2[i];
            break;
          } else {
            this.exist = false;
          }
        }
      }
    )
  }

}
