import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.scss']
})
export class AddmovieComponent implements OnInit {



  constructor(private http: Http) { }
  confirmationString:string = "New movie has been added";
  isAdded: boolean = false;
  productObj:object = {};
  

  addNewProduct = function(student) {
    this.productObj = {
      "id":student.id,
      "image":student.image.replace("C:\\fakepath\\","/assets/images/"),
      "name": student.name,
      "screen": student.screen,
      "language": student.language,
      "type": student.type,
      "duration": student.duration
    }
    this.http.post("http://localhost:5200/students/", this.productObj).subscribe((res:Response) => {
      this.isAdded = true;
    })
  }

  ngOnInit() {
  }

}
