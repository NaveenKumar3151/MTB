import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import {ActivatedRoute } from '@angular/router';
import {Router} from '@angular/router';

@Component({
  selector: 'app-updatemovie',
  templateUrl: './updatemovie.component.html',
  styleUrls: ['./updatemovie.component.scss']
})
export class UpdatemovieComponent implements OnInit {


  id:number;
  data:any = {};
  students = [];
  exist = false;
  productObj:object = {};
  
  private headers = new Headers({ 'Content-Type': 'application/json'});

  constructor(private router: Router, private route: ActivatedRoute, private http: Http) { }

  updateProduct(student) {
    this.productObj = {
      "id":student.id,
      "image":student.image.replace("C:\\fakepath\\","/assets/images/"),
      "name": student.name,
      "screen": student.screen,
      "language": student.language,
      "type": student.type,
      "duration": student.duration
    };
    const url = `${"http://localhost:5200/students"}/${this.id}`;
    this.http.put(url, JSON.stringify(this.productObj),{headers: this.headers})
      .toPromise()
      .then(() => {
        this.router.navigate(['/admin']);
      })
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = +params['id'];
    });
    this.http.get("http://localhost:5200/students").subscribe(
      (res: Response) => {
        this.students = res.json();
        for(var i = 0; i < this.students.length ; i++) {
          if(parseInt(this.students[i].id) === this.id) {
            this.exist = true;
            this.data = this.students[i];
            break;
          } else {
            this.exist = false;
          }
        }
      }
    )
  }


}
