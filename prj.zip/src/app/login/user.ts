export class user{

    constructor(

  
    public username:string,
    public password:string,

    )
    {

    }
    

}