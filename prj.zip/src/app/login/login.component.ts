import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms'
import { user } from './user';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ApitestService } from '../apitest.service';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  @ViewChild('f') public loginForm: NgForm;
  model = new user("","");

  confirmationString:string = "New movie has been added";
  isAdded: boolean = false

  username: string;
  password: string;


  constructor(private router: Router, private httpclient: HttpClient, private apitestservice: ApitestService,private authService:AuthService) { }
  public getdata = [];
  count: number;

  getAllDetails(){
    this.apitestservice.getDetails().subscribe((data) => {
      // console.log("data",data);
      this.getdata = data;
      console.log("getdata", this.getdata);
    })
  }

  ngOnInit(): void {
    this.getAllDetails();
  }

  onSubmit(loginForm)
  {
    if (loginForm.valid) {
      this.authService.login(this.loginForm.value);
      console.log("username: " + loginForm.controls.username.value + 'password: ' + loginForm.controls.password.value);
      for (var i = 0; i < this.getdata.length; i++) {
        if ((loginForm.controls.username.value == this.getdata[i].username) &&
          (loginForm.controls.password.value == this.getdata[i].password)) {
          if (this.getdata[i].role === "user") {
            this.count = 1;
            break;
          }
          else {
            this.count = 2;
            break;
          }
        }
        else {
          this.count = 0;
        }
      }
    }
    else {
      alert("You entered wrong or missed some of the credentials");
    }
    console.log(this.count);
    if (this.count == 1)
      this.router.navigate(['/user']);
    else if(this.count == 2)
    this.router.navigate(['/admin']);
else
    alert("You entered incorrect userid or password");
  }

}
