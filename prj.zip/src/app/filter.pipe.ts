import { Pipe, PipeTransform } from '@angular/core';
import { Items } from 'src/model';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(students: Items[], searchTerm: string): Items[] {
    if (!students || !searchTerm) {
        return students;
    }

    return students.filter(student =>
        student.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
}
}
