import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApitestService {


  details:string=" http://localhost:5200/details"
  



  constructor(private http: HttpClient) { }

  getDetails() : Observable <any>{
    return this.http.get(this.details);

  }

}
