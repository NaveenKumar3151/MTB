import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { ContactComponent } from './contact/contact.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AddmovieComponent } from './admin/addmovie/addmovie.component';
import { UpdatemovieComponent } from './admin/updatemovie/updatemovie.component';
import { AddumovieComponent } from './admin/addumovie/addumovie.component';
import { UpdateumovieComponent } from './admin/updateumovie/updateumovie.component';
import { SeatchartComponent } from './user/seatchart/seatchart.component';
import { UserdetailsComponent } from './user/userdetails/userdetails.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


const routes: Routes = [
  {path:' ',component:HomeComponent },
  {path:'home',component:HomeComponent },
  {path:'login',component:LoginComponent },
  {path:'register',component:RegisterComponent},
  {path:'contact',component:ContactComponent },
  {path:'reset-password',component:ResetPasswordComponent },
  {path:'admin',component:AdminComponent },
  {path:'user',component:UserComponent},
  {path:'seatchart',component:SeatchartComponent },
  {path:'userdetails',component:UserdetailsComponent },
  {path:'addmovie',component:AddmovieComponent},
  {path:'updatemovie/:id',component:UpdatemovieComponent },
  {path:'addumovie',component:AddumovieComponent },
  {path:'updateumovie/:id',component:UpdateumovieComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
