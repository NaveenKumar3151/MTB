import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { Router } from '@angular/router';
import{Location} from'@angular/common'
import { User } from 'src/app/auth/authuser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  isLoggedIn :any;
  isHome=false;
  route:string;
  private user:User;

  constructor(private authService:AuthService,location:Location,router : Router) { 

    router.events.subscribe(val => {
      if(location.path()!=""){
        this.route=location.path();
      }
      else{
        this.route="/home";
      }
      if(this.route==='/aboutus'||this.route==='/reset-password'||this.route==='/admin'||this.route==='/home' || this.route==='/contact'||this.route==='/register'||this.route==='/login'){
        this.isHome=true;
      }
      else{
        this.isHome=false;
      }
    });
  }

  ngOnInit() {
    this.authService.isLoggedIn.subscribe(x=>{
      this.isLoggedIn=x;
    });
  }

  onLogout(){
    this.authService.logout();
    this.isHome=true;
  }

}
