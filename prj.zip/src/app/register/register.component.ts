import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms'

import{Http,Response,Headers}from'@angular/http'


import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl:'./register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {


  @ViewChild('f') public registerForm :NgForm;
  

  registerUserData = {
    'firstname': '','lastname': '',
    'username': '', 'email': '',
    'password': '','cpassword':''
  }
  
  

  constructor(private http: Http,private router: Router) {
  }


  userdetailObj: object = {};
  addUser = function (userdetail) {
    this.userdetailObj = {
      "username": userdetail.username,
      "password": userdetail.password,
      "role": userdetail.role
    }
    this.http.post("http://localhost:5200/details/", this.userdetailObj).subscribe((res: Response) => {
      console.log(res);
    })
  }

  details = [];
  fetchData = function () {

    this.http.get("http://localhost:5200/details").subscribe(
      (res: Response) => {
        this.details = res.json();
      }
    )
  }

 

  ngOnInit(){
    this.fetchData();
  }

  submitted

  onSubmit() {
    this.submitted = true;
   
    
      this.router.navigate(['/login']);
    }
  

}
