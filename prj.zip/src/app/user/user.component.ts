import { Component, OnInit } from '@angular/core';
import {Http, Response, Headers} from '@angular/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  searchTerm :string;
  id:number;

  constructor(private http: Http) { }
  
 
  private headers = new Headers({ 'Content-Type': 'application/json'});

  students = [];
  fetchData = function() {
    this.http.get("http://localhost:5200/students").subscribe(
      (res: Response) => {
        this.students = res.json();
      }
    )
  }

  

  
  students2 = [];
  fetchData2 = function() {
    this.http.get("http://localhost:5200/students2").subscribe(
      (res: Response) => {
        this.students2 = res.json();
      }
    )
  }

  

  ngOnInit() {
    this.fetchData();
    this.fetchData2();

  }

  notify(){
    alert('You will get notification when movie got released')
  }
}
