export class Items {
    id: number;
    name: string;
    language:string;
    type:string;
    duration:string;
    
}